# -*- coding: UTF-8 -*-

from behave import given, then, when

from features.support.actions.loginaction import LoginAction
from features.support.pageactions.homepage import HomePage

from utils.assertutils import Assert

# ===============================================================================================
# STEP DEFINITIONS:
# ===============================================================================================


@given(u'I navigate to ormuco url')
def step_impl(context):
    # Save the references of actions and page actions object in context.scenario
    # So that We can use the same object references in other steps
    context.logger.info("Opening application url '" + context.application_url + "'")
    context.driver.get(context.application_url)
    context.driver.maximize_window()


@when(u'I login using below credentials')
def step_impl(context):
    context.scenario.login_action = LoginAction(context)

    context.scenario.search_page = None

    for row in context.table:
        context.scenario.search_page = context.scenario.login_action.login(row['username'], row['password'])


@then(u'I should see the below error message')
def step_impl(context):
    context.scenario.home_page = HomePage(context)

    for row in context.table:
        Assert.assert_true(context.scenario.home_page.is_error_message_displayed(row['error_message']),
                           "Invalid login error message is not displayed")
