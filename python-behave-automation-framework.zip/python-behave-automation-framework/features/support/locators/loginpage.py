# -*- coding: UTF-8 -*-

# ----------------------------------------------------------------------------
#   SUPPORTED LOCATOR STRATEGIES:
#       * XPATH
#       * ID
#       * NAME
#       * CSS_SELECTOR
#       * TAG_NAME
#       * LINK_TEXT
#       * PARTIAL_LINK_TEXT
# ----------------------------------------------------------------------------

email_text_field = "ID,username"
password_field = "ID,password"
signin_button = "XPATH,//div[@ng-switch='dual_auth']/button"
