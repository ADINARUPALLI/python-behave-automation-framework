# -*- coding: UTF-8 -*-

from features.support.pageactions.loginpage import LoginPage
from features.support.pageactions.homepage import HomePage


class LoginAction(object):
    """Action class to perform operations related to login
    """
    def __init__(self, context):
        self.context = context

        self.login_page = LoginPage(self.context)

    def login(self, email_address, password):
        """Login to application
        :param email_address: Email address of the user
        :param password: Password of the user
        :return: home page
        """
        self.login_page.type_email(email_address)
        self.login_page.type_password(password)
        self.login_page.click_on_sign_in_button()

        return HomePage(self.context)
