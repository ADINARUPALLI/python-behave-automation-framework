# -*- coding: UTF-8 -*-

from features.support.pageactions.basepage import BasePage

from features.support.locators import homepage as homepage_locators


class HomePage(BasePage):
    """Action class to perform different actions on home page
    Usage: home_page = HomePage(context)
    home_page.type_username('demouser')
    """
    def __init__(self, context):
        super(HomePage, self).__init__(context)

    def is_error_message_displayed(self, error_message):
        return self.element_action.is_element_displayed(homepage_locators.invalid_login_text,
                                                        replacement=error_message)
