# -*- coding: UTF-8 -*-

from features.support.pageactions.basepage import BasePage

from features.support.pageactions.homepage import HomePage
from features.support.locators import loginpage as loginpage_locators


class LoginPage(BasePage):
    """Action class to perform different actions on login page.
    """
    def __init__(self, context):
        super(LoginPage, self).__init__(context)

    def type_email(self, email):
        self.element_action.type(loginpage_locators.email_text_field, email)

    def type_password(self, password):
        self.element_action.type(loginpage_locators.password_field, password)

    def click_on_sign_in_button(self):
        self.element_action.click(loginpage_locators.signin_button)

        return HomePage(self.context)

