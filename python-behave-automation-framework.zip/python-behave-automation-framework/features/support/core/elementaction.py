# -*- coding: UTF-8 -*-


from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.common.exceptions import TimeoutException, \
    StaleElementReferenceException, NoSuchElementException

from selenium.webdriver.common.action_chains import ActionChains

from utils.assertutils import Assert


class ElementAction(object):
    """Action class to perform basic operations (click, type, select ...) on webpage elements
    """
    # Element locator strategies
    locator_strategies = ['XPATH', 'ID', 'NAME', 'CLASS_NAME', 'LINK_TEXT',
                          'CSS_SELECTOR', 'PARTIAL_LINK_TEXT', 'TAG_NAME']

    def __init__(self, context):
        self.context = context

    def fetch_element(self, locator, is_list_of_elements=False, element_timeout=None):
        """Fetch the WebElement
        Find the web element based the specified locator. Before attempting to find the element,
        check if presence and visibility of it is found.
        :param locator: element locator
        :param is_list_of_elements: in case the locator returns multiple elements, set this to true
        :param element_timeout: By default webdriver will wait for the 'element_fetch_timeout' seconds defined in
        config file. It will be overridden if you specify a different timeout to this function
        :return: WebElement, raise exception in case no such element is found
        """
        strategy = locator.split(",")[0].strip()
        actual_locator = locator.replace(strategy + ",", "")

        if element_timeout is None:
            element_timeout = int(self.context.config['env']['element_fetch_timeout'])

        try:

            if strategy not in ElementAction.locator_strategies:
                raise KeyError("Unsupported locator strategy - " + strategy + "! " +
                               "Supported locator strategies are 'XPATH', 'ID', 'NAME', "
                               "'CSS_SELECTOR', 'TAG_NAME', 'LINK_TEXT' and 'PARTIAL_LINK_TEXT'")

            try:
                WebDriverWait(self.context.driver, element_timeout).until(
                    ec.visibility_of_element_located((getattr(By, strategy), actual_locator))
                )
            except(TimeoutException, StaleElementReferenceException):
                self.context.logger.error("Timed out after '" + str(element_timeout) +
                                          "' seconds waiting for element '" + str(actual_locator) +
                                          "' to be present!", exc_info=True)

            if is_list_of_elements:
                return self.context.driver.find_elements(getattr(By, strategy), actual_locator)

            try:
                element = self.context.driver.find_element(getattr(By, strategy), actual_locator)

                return element
            except TypeError:
                return False

        except NoSuchElementException:
            raise NoSuchElementException("Unable to locate element on page: {'strategy': '" +
                                         str(strategy) + "', 'locator': '" + str(actual_locator) + "'}")

    def is_element_displayed(self, locator, replacement=None, timeout=None):
        """Verify if element is present on page
        :param locator: element locator
        :param replacement: if locator contains dynamic part, i.e. '$value',
        it will be replaced by replacement variable
        :param timeout: By default webdriver will wait for the 'element_fetch_timeout' seconds defined
        in config.yml. It will be overridden if you specify a different timeout to this function
        :return: Boolean value specifying if element is displayed!
        """
        if replacement is not None:
            locator = locator.replace('$value', replacement)

        try:
            if not self.fetch_element(locator, False, timeout):
                return False
            return self.fetch_element(locator, False, timeout).is_displayed()
        except Exception:
            return False

    def click(self, locator, replacement=None, click_using_java_script=False):
        """Click on element
        :param locator: locator on which to click
        :param replacement: if locator contains dynamic part, i.e. '$value',
        it will be replaced by replacement variable
        :param click_using_java_script: whether to click using java script
        :return: None
        """
        if replacement:
            locator = locator.replace('$value', replacement)

        if click_using_java_script:
            _ele = self.fetch_element(locator)
            self.execute_java_script("arguments[0].click();", _ele)
            self.context.logger.info("Clicked on element '" + locator + "' using java script")
        else:
             try:
                strategy = locator.split(",")[0].strip()
                actual_locator = locator.replace(strategy + ",", "")

                timeout = int(self.context.config['env']['element_fetch_timeout'])

                WebDriverWait(self.context.driver, timeout).until(
                        ec.element_to_be_clickable((getattr(By, strategy), actual_locator))
                    )

                _ele = self.fetch_element(locator)

                if click_using_java_script:
                    self.execute_java_script("arguments[0].click();", _ele)
                else:
                    _ele.click()

                    self.context.logger.info("Clicked on element '" + locator + "'")

             except Exception as e:

                if 'safari' not in self.context.browser:
                    self.context.logger.info("Unable to click on element '" + locator +
                                             "'. Trying to click using Action Chains")

                    try:
                        element = self.fetch_element(locator)

                        actions = ActionChains(self.context.driver)
                        actions.move_to_element(element)
                        actions.click(element)
                        actions.perform()

                        self.context.logger.info("Action Chains - Clicked on element '" + locator + "'")
                    except Exception as e:
                        self.context.logger.error("Unable to click on element '" + locator + "'. Error: %s" % e,
                                                  exc_info=True)
                        Assert.assert_fail("Unable to click on element '" + locator + "'")

    def type(self, locator, text, replacement=None):
        """Type text in locator
        :param locator: locator in which to type
        :param text: text to type
        :param replacement: if locator contains dynamic part, i.e. '$value',
        it will be replaced by replacement variable
        :return: None
        """
        if replacement:
            locator = locator.replace('$value', replacement)

        try:

            _element = self.fetch_element(locator)
            _element.clear()
            _element.send_keys(text)
            self.context.logger.info("Typed text '" + text + "' on element '" + locator + "'")
        except Exception as e:
            self.context.logger.error("Unable to type text '" + text + "' on element '" + locator + "'. Error: %s" % e,
                                      exc_info=True)
            Assert.assert_fail("Unable to type text '" + text + "' on element '" + locator + "'")

    def execute_java_script(self, script, element=None):
        """Execute raw java script statements
        :param script: java script to execute
        :param element: webdriver element on which to execute the java script
        :return: None
        """
        try:
            if element:
                return self.context.driver.execute_script(script, element)
            else:
                return self.context.driver.execute_script(script)
        except Exception as e:
            self.context.logger.error("Unable to execute java script '" + script + "'. Error: %s" % e,
                                      exc_info=True)
            Assert.assert_fail("Unable to execute java script '" + script + "'")
